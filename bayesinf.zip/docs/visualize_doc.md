"""Visualization tools for results and summaries."""

def plot_parameters(...):
    """
    Plots inferred vs. true parameter values over time.
    """

def show_summary(...):
    """
    Prints final inferred values in a comparison table.
    """